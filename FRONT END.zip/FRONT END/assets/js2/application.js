/* -------------------------------------------------------------------------------- /
  
  SmartOn jQuery
  Created by 4grafx and ws-theme
  v1.1 - 28.11.2013
  All rights reserved.

  +----------------------------------------------------+
    TABLE OF CONTENTS
  +----------------------------------------------------+
  
  [1]   Bootstrap
  [2]   Navigation
  [3]   Toggle
  [4]   Carousel
  [5]   ScrollToTop
  [6]   Animate
  [7]   GoogleMap
  [8]   Revolution Slider
  [9]   Lightbox
  [10]  Preloader
  [11]  Parallex
  [12]  Sticky Header
  [13]  Animation in Viewport
  [14]  Isotope Portfolio
  
/ -------------------------------------------------------------------------------- */

var gfx=jQuery;
gfx.noConflict();


/* ---------------------------------------------------
  Default Bootstrap
-------------------------------------------------- */


!function (gfx) {

  gfx(function(){
    // Bootstrap Tooltip


    // Bootstrap Popover
    gfx("[data-toggle=popover]")
      .popover()
    }
  )
}(window.jQuery)


/* ---------------------------------------------------
  Main Menu
-------------------------------------------------- */

gfx(function() {
  gfx('#main-menu').smartmenus({
    subMenusSubOffsetX: 0,
    subMenusSubOffsetY: 0,
    markCurrentItem:  true,
    subIndicatorsText:  '<i class="fa fa-plus"></i>',
    subIndicatorsPos:   'append', // position of the SPAN relative to the menu item content ('prepend', 'append')
    showTimeout:    50,   // timeout before showing the sub menus
    hideTimeout:    50,   // timeout before hiding the sub menus
    
    collapsibleShowFunction: function($ul, complete) { $ul.slideDown(200, complete); },
    collapsibleHideFunction: null,
    showFunction: function($ul, complete) { $ul.slideDown(200, complete); },
    hideFunction: function($ul, complete) { $ul.slideUp(200, complete); }
  });
  
  gfx(".menu li").hover(
    function(){
        gfx(this).children('ul').hide();
        gfx(this).children('ul').slideDown('fast');
    },
    function () {
        gfx('ul', this).slideUp('fast');            
    });
});



gfx(function() {
  gfx('#menu-button').click(function() {
    var $this = gfx(this),
        $menu = gfx('#main-menu');
    if (!$this.hasClass('collapsed')) {
      $menu.addClass('collapsed');
      $this.addClass('collapsed');
    } else {
      $menu.removeClass('collapsed');
      $this.removeClass('collapsed');
    }
    return false;
  }).click();
});









/* ---------------------------------------------------
  click/tap to toggle the sub menus in collapsible mode
-------------------------------------------------- */


gfx('#main-menu').bind('show.smapi', function(e, menu) {
  gfx(menu).dataSM('parent-a').children('span.sub-arrow').html('<i class="fa fa-minus"></i>');
});

gfx('#main-menu').bind('hide.smapi', function(e, menu) {
  gfx(menu).dataSM('parent-a').children('span.sub-arrow').html('<i class="fa fa-plus"></i>');
});


/* ---------------------------------------------------
  Toggle Divs
-------------------------------------------------- */


gfx(document).ready(function(){

  gfx('div.toggle-container').each(function() {
    var $dropdown = gfx(this);
    gfx("a.toggle-link", $dropdown).click(function(e) {
      e.preventDefault();
      $div = gfx("div.togglebox", $dropdown);
    gfx(this).toggleClass('close-link');
      $div.fadeToggle(150).animate({'top': '10px', "opacity":"1"}, 300) ;
      gfx("div.togglebox").not($div).fadeOut(150).animate({'top': '30px', "opacity":"0"}, 300);
      return false;
    });
  });
    
  gfx('html').click(function(){
    gfx("div.togglebox").fadeOut(150).animate({'top': '30px', "opacity":"0"}, 300);
  });
  gfx("div.togglebox").click(function(e) {
    e.stopPropagation();
  });
     
});


/* ---------------------------------------------------
  Tooltipster
-------------------------------------------------- */


    gfx(document).ready(function() {
       gfx('.tooltip-on, .hasTooltip').tooltipster({
   animation: 'fade',
   arrow: true,
   arrowColor: '',
   delay: 0,
   fixedWidth: 0,
   maxWidth: 300,
   functionBefore: function(origin, continueTooltip) {
      continueTooltip();
   },
   functionReady: function(origin, tooltip) {},
   functionAfter: function(origin) {},
   icon: '(?)',
   iconDesktop: false,
   iconTouch: false,
   iconTheme: '.tooltipster-icon',
   interactive: true,
   interactiveTolerance: 150,
   offsetX: 0,
   offsetY: 0,
   onlyOne: true,
   speed: 200,
   timer: 0,
   theme: '.tooltipster-default',
   touchDevices: true,
   trigger: 'hover',
   updateAnimation: true,
   contentAsHTML: true
});
    });


/* ---------------------------------------------------
  Team Toggle
-------------------------------------------------- */


gfx(document).ready(function(){
  gfx(".toggle-staff").click(function(){    
    var target = gfx(this).parent().children(".staff-info");
    gfx(target).slideToggle();
  gfx(this).toggleClass('toggle-close');
  });
});


/* ---------------------------------------------------
  Back to Top
-------------------------------------------------- */


gfx(document).ready(function(){
 
  gfx(window).scroll(function(){
      if (gfx(this).scrollTop() > 100) {
          gfx('.scrollup').fadeIn();
      } else {
          gfx('.scrollup').fadeOut();
      }
  });
  
  gfx('.scrollup').click(function(){
      gfx("html, body").animate({ scrollTop: 0 }, 800);
      return false;
  });
 
});



    gfx(function(){
      gfx.stellar({
        horizontalScrolling: false,
        verticalOffset: 0,
      });
    });
    

gfx(window).load(function(){
  gfx(".header-bottom").sticky({ topSpacing: 0, center:false, className:"visible" });
});



/* ---------------------------------------------------
  Animation on Scroll
-------------------------------------------------- */
    
    
gfx('.animation').waypoint(function(direction) {
  gfx(this).addClass('animation-active');
}, { offset: '100%' });

gfx('.countto').counterUp({
  delay: 10,
  time: 1500
});


    
/* ---------------------------------------------------
  Panel Slide
-------------------------------------------------- */


gfx(document).ready(function(){

  gfx(".slide-panel-btn").click(function(){
    gfx("#slide-panel").slideToggle(250);
    gfx(this).toggleClass("active"); return false;
  });
  
  gfx(".login-toggle").click(function(){
    gfx(".login-toggle-content").slideToggle(250);
    gfx(this).toggleClass("active"); return false;
  });
  
   
});

/* ---------------------------------------------------
  Countdown









gfx(function(){
  
  var $window = gfx(window);    //Window object
  
  var scrollTime = 1;     //Scroll time
  var scrollDistance = 400;   //Distance. Use smaller value for shorter scroll and greater value for longer scroll
    
  $window.on("mousewheel DOMMouseScroll", function(event){
    
    event.preventDefault(); 
                    
    var delta = event.originalEvent.wheelDelta/120 || -event.originalEvent.detail/3;
    var scrollTop = $window.scrollTop();
    var finalScroll = scrollTop - parseInt(delta*scrollDistance);
      
    TweenMax.to($window, scrollTime, {
      scrollTo : { y: finalScroll, autoKill:true },
        ease: Power1.easeOut, //For more easing functions see http://api.greensock.com/js/com/greensock/easing/package-detail.html
        autoKill: true,
        overwrite: 5              
      });
          
  });
  
  
  
});

-------------------------------------------------- */
